#! /usr/bin/env bash
ssh dev@192.168.56.123 exit 0 > /dev/null 2>&1
wynik=$?
if [ $wynik -eq 0 ]; then
    echo "Można się połączyć z hostem po ssh"
else
    echo "Nie można się połączyć z hostem po ssh"
fi