#! /usr/bin/env bash
if [ $# -gt 0 ]; then
    nazwa_pliku=$1;
else
    nazwa_pliku="data.txt";
fi
echo $(date) > $nazwa_pliku   