#! /usr/bin/env bash
scp /home/dev/code/top_df_local.sh dev@192.168.56.123:/home/dev/top_df_local.sh
wynik=$?
if [ $wynik -eq 0 ]; then
    katalog=$(date +"%Y%m%d_%H%M%S")
    ssh dev@192.168.56.123 '. /home/dev/top_df_local.sh '$katalog'' 
    if [ $wynik -eq 0 ]; then
            scp -r dev@192.168.56.123:/home/dev/$katalog /home/dev/code/
    else
            echo "Coś poszło nie tak"
    fi
else
    echo "Coś poszło nie tak"
fi