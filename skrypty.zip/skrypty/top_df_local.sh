#! /usr/bin/env bash
if [ $# -gt 0 ]; then
    katalog=$1;
else
    katalog=$(date +"%Y%m%d_%H%M%S");
fi
mkdir $katalog 
top -n1 -b > ./$katalog/wynik.log
echo "===============================" >> ./$katalog/wynik.log
df -h >> ./$katalog/wynik.log